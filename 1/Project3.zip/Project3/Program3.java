import java.util.Arrays;

public class Program3 {

    public int maxFoodCount (int[] sections) {
        if (sections.length < 2) return 0;

        int wall = (sections.length - 1)/2;
        int bwall = wall;
        int leftSum = 0;
        int rightSum = 0;
        int smaller;
        int max = 0;

        for (int i = 0; i <= wall; i++){
            leftSum += sections[i];
        }
        for(int i = wall + 1; i < sections.length; i++){
            rightSum += sections[i];
        }

        if(leftSum < rightSum){
            smaller = leftSum;
            do{
                if(max != smaller) bwall = wall;
                max = smaller;
                wall++;
                leftSum += sections[wall];
                rightSum -= sections[wall];
                smaller = leftSum < rightSum ? leftSum : rightSum;
            }while(!(smaller < max));
            leftSum -= sections[wall];
            rightSum += sections[wall];
            wall--;
        }else if (leftSum > rightSum){
            smaller = rightSum;
            do{
                if(max != smaller) bwall = wall;
                max = smaller;
                leftSum -= sections[wall];
                rightSum += sections[wall];
                wall--;
                smaller = leftSum < rightSum ? leftSum : rightSum;
            }while(!(smaller < max));
            wall++;
            leftSum += sections[wall];
            rightSum -= sections[wall];
        }else{
            return leftSum + Math.max(maxFoodCount(Arrays.copyOfRange(sections, 0, wall + 1)), 
                            maxFoodCount(Arrays.copyOfRange(sections, wall + 1, sections.length)));
        }

        if(bwall == wall){
            if(max == leftSum){
                return max + maxFoodCount(Arrays.copyOfRange(sections, 0, wall + 1));
            }else return max + maxFoodCount(Arrays.copyOfRange(sections, wall + 1, sections.length));
        }else{
            if (max == leftSum){
                return Math.max(max + maxFoodCount(Arrays.copyOfRange(sections, 0, wall + 1)), max + maxFoodCount(Arrays.copyOfRange(sections, bwall + 1, sections.length)));
            }else{
                return Math.max(max + maxFoodCount(Arrays.copyOfRange(sections, 0, bwall + 1)), max + maxFoodCount(Arrays.copyOfRange(sections, wall + 1, sections.length)));
            }
        }
    }
}
